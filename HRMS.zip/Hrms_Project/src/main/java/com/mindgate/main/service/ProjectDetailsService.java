package com.mindgate.main.service;

public class ProjectDetailsService implements ProjectDetailsServiceInterface {

}
